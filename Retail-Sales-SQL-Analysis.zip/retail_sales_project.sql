-- Retail Sales SQL Analysis Project

-- Change sales_time format
ALTER TABLE Retail_Sales
ALTER COLUMN Sale_time TIME(0);

-- change column name quantiy to quantity
EXEC SP_RENAME 'Retail_Sales.quantiy' ,'quantity','column';

-- How many records in my table
SELECT count(*) total_data FROM Retail_Sales;

-- Data cleaning: check and delete null values
SELECT * FROM Retail_Sales
WHERE transactions_id IS NULL 
      OR sale_date IS NULL OR sale_time IS NULL
      OR customer_id IS NULL OR gender IS NULL
      OR category IS NULL OR quantity IS NULL
      OR price_per_unit IS NULL OR cogs IS NULL OR total_sale IS NULL;

DELETE FROM Retail_Sales
WHERE transactions_id IS NULL 
      OR sale_date IS NULL OR sale_time IS NULL
      OR customer_id IS NULL OR gender IS NULL
      OR category IS NULL OR quantity IS NULL
      OR price_per_unit IS NULL OR cogs IS NULL OR total_sale IS NULL; 

-- Data Exploration
SELECT count(*) AS Total_Sales FROM Retail_Sales;
SELECT COUNT(distinct(customer_id)) AS total_customers FROM Retail_Sales;
SELECT DISTINCT(category) FROM Retail_Sales;
SELECT SUM(total_sale) AS Total_Sales FROM Retail_Sales;
SELECT category, SUM(total_sale) AS Total_Sales FROM Retail_Sales GROUP BY category;
SELECT category, SUM(quantity) AS Total_Qty_Sale FROM Retail_Sales GROUP BY category;
SELECT DISTINCT(category), price_per_unit FROM Retail_Sales;

-- Business Problems and Solutions
-- Q1
SELECT * FROM Retail_Sales WHERE sale_date = '2022-11-05';
-- Q2
SELECT * FROM Retail_Sales
WHERE category = 'Clothing' AND quantity > 2 
AND sale_date BETWEEN '2022-11-01' AND '2022-11-30'
ORDER BY sale_date ASC;
-- Q3
SELECT category, SUM(total_sale) AS Total_Sales, SUM(quantity) AS Total_orders FROM Retail_Sales GROUP BY category;
-- Q4
SELECT AVG(age) AS avg_age FROM Retail_Sales WHERE category = 'beauty';
-- Q5
SELECT * FROM Retail_Sales WHERE total_sale >= 1000;
-- Q6
SELECT category, gender, COUNT(transactions_id) AS total_no_of_transaction FROM Retail_Sales GROUP BY category, gender;
-- Q7
SELECT MONTH(Sale_date) AS month, AVG(total_sale) AS average_sales FROM Retail_Sales GROUP BY MONTH(Sale_date) ORDER BY MONTH(Sale_date);
SELECT Year, month, total_sales FROM(
    SELECT YEAR(sale_date) AS Year, MONTH(Sale_date) AS month, SUM(total_sale) AS total_sales,
           RANK() OVER(PARTITION BY YEAR(sale_date) ORDER BY SUM(total_sale) DESC) AS RANK
    FROM Retail_Sales
    GROUP BY YEAR(sale_date), MONTH(sale_date)
) AS T1 WHERE RANK = 1;
-- Q8
SELECT TOP 5 customer_id, SUM(total_sale) AS Total_Sales FROM Retail_Sales GROUP BY customer_id ORDER BY SUM(total_sale) DESC;
-- Q9
SELECT customer_id, COUNT(DISTINCT(category)) AS category_count,
       CASE WHEN COUNT(DISTINCT(category)) = 3 THEN 'YES' ELSE 'NO' END AS Purchased_from_all_ctgry_status
FROM Retail_Sales GROUP BY customer_id ORDER BY customer_id ASC;
-- Q10
SELECT Shift, COUNT(Shift) AS Total_orders FROM(
    SELECT CASE
        WHEN DATEPART(HOUR, sale_time) <= 12 THEN 'morning'
        WHEN DATEPART(HOUR, sale_time) > 12 AND DATEPART(HOUR, sale_time) <= 17 THEN 'afternoon'
        ELSE 'evening' END AS Shift
    FROM Retail_Sales
) AS T1 GROUP BY Shift;
